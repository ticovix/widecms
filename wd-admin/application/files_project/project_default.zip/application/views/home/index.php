<html>
	<head>
		<title>New Project</title>
	</head>
	<body>
		<h1>New project? Good job!</h1>
	</body>
</html>