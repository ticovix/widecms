<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require_once(BASEPATH . '../application/config/database.php');
